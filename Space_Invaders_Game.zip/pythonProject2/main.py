import pygame
import random

""" Setting up the window """
pygame.init()
pygame.font.init()
pygame.display.set_caption("Hello World Invaders")

width = 800
height = 400
game_Window = pygame.display.set_mode((width, height))
menu_Window = pygame.display.set_mode((width, height))
""" GAME SCREEN FEATURES """
# Setting game & menu background and making sure its to scale
game_background = pygame.transform.scale(pygame.image.load('background_image.png'), (width, height))
menu_BG = pygame.transform.scale(pygame.image.load('menu_background.png'), (width, height))

# Adding characters and players laser
players_Image = pygame.image.load('HW_Player.png')
players_laser = pygame.image.load('neon_green_laser.png')

hello_BLACK = pygame.transform.scale(pygame.image.load('Hello_BLACK.png'), (64, 64))
hello_CYAN = pygame.transform.scale(pygame.image.load('Hello_CYAN.png'), (64, 64))
hello_GREEN = pygame.transform.scale(pygame.image.load('Hello_GREEN.png'), (64, 64))
hello_PURPLE = pygame.transform.scale(pygame.image.load('Hello_PURPLE.png'), (64, 64))
printLn_IMAGE = pygame.transform.scale(pygame.image.load('print_ln.png'), (64, 64))


""" Creating an overall Ship class """
class Ship:
    # Creating a class that the player and enemy will inherit from

    LASER_COOLDOWN = 30  # Creating half a second cooldown

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.ship_img = None
        self.laser_img = players_laser
        self.lasers = []
        self.laser_cooldown_counter = 0

    def draw(self, window):
        window.blit(self.ship_img, (self.x, self.y))

        for laser in self.lasers:
            laser.draw(window)

    def cooldown(self):
        if self.laser_cooldown_counter >= self.LASER_COOLDOWN:
            self.laser_cooldown_counter = 0
        elif self.laser_cooldown_counter > 0:
            self.laser_cooldown_counter += 1

    # Getting a certain ships x & y co-ordinates
    def get_width(self):
        return self.ship_img.get_width()

    def get_height(self):
        return self.ship_img.get_height()


""" CREATING PLAYER MODEL + ASSETS
(Ship) means it will inherit from that class """
class Player_Model(Ship):

    def __init__(self, x, y):
        super().__init__(x, y)
        self.ship_img = players_Image
        self.laser_img = players_laser
        self.scores = 0
        # Making a mask of the image
        self.mask = pygame.mask.from_surface(self.ship_img)

    # Checking if cooldown is over
    def shoot(self):
        if self.laser_cooldown_counter == 0:
            laser = Lasers(self.x - 18, self.y, self.laser_img)  # WHERE IT COMES OUT OF SHIP
            self.lasers.append(laser)
            self.laser_cooldown_counter = 1

    def move_lasers(self, velocity, objs):
        self.cooldown()
        for laser in self.lasers:
            laser.move(velocity)
            if laser.off_screen(height):
                self.lasers.remove(laser)  # removes laser when off screen
            else:
                for obj in objs:
                    if laser.collision(obj):
                        objs.remove(obj)
                        self.lasers.remove(laser)
                        self.scores += 1


""" LASER CLASS"""
class Lasers:
    def __init__(self, x, y, laser_img):
        self.x = x
        self.y = y
        self.laser_img = laser_img
        self.mask = pygame.mask.from_surface(self.laser_img)

    def draw(self, window):
        window.blit(self.laser_img, (self.x, self.y))

    def move(self, laser_velocity):
        self.y += laser_velocity

    def off_screen(self, height):
        return not (height >= self.y >= 0)

    def collision(self, obj):
        return collide(self, obj)


""" COLLISION DETECTION """
def collide(obj1, obj2):
    ''' creating a hit box for each object within the game '''
    offset_x = obj2.x - obj1.x  # calculating the distance between 2 objects
    offset_y = obj2.y - obj1.y
    return obj1.mask.overlap(obj2.mask, (offset_x, offset_y)) is not None
    # checking whether the 2 objects overlap each other ( as if they collide)


""" ENEMY CLASS """
class Enemy(Ship):
    DIFF_COLOUR = {
        "BLACK": hello_BLACK,
        "GREEN": hello_GREEN,
        "CYAN": hello_CYAN,
        "PURPLE": hello_PURPLE,
        "YELLOW": printLn_IMAGE
    }

    def __init__(self, x, y, color):
        super().__init__(x, y)
        self.ship_img = self.DIFF_COLOUR[color]
        self.mask = pygame.mask.from_surface(self.ship_img)

    def move(self, velocity):
        self.y += velocity


""" GAME LOOP """
def main_Game():
    running = True
    FPS = 60  # Setting to 60FPS
    level = 0   # Starting level for the player
    lives = 5   # Number of lives the Player has

    # Creating fonts for the game titles e.g. the Score:
    game_font = pygame.font.SysFont("comicsans", 25)
    losing_font = pygame.font.SysFont("comicsans", 70)

    # Lost page
    Lost = False
    lost_screen_timer = 0

    # Enemy Information
    enemies = []
    wave_length = 3  # How many enemies we add for each round
    enemy_velocity = 1  # speed of each enemy

    # Player Information & Laser
    player_velocity = 5
    player = Player_Model(400, 330)
    laser_velocity = 6

    # Setting FPS
    clock = pygame.time.Clock()

    def redraw():
        game_Window.blit(game_background, (0, 0))

        # Score Display
        score_title = (game_font.render(f"Score: {player.scores}", 1, (255, 255, 255)))
        game_Window.blit(score_title, (10, 10))

        # Level Display
        level_title = game_font.render(f"Level: {level}", 1, (255, 255, 255))
        game_Window.blit(level_title, (width - level_title.get_width() - 10, 10))

        # Lives Display
        lives_title = game_font.render(f"Lives: {lives}", 1, (255, 255, 255))
        game_Window.blit(lives_title, (10, 30))

        # Drawing Enemy
        for enemy in enemies:
            enemy.draw(game_Window)

        # Drawing Player
        player.draw(game_Window)

        if Lost:
            lost_Title = losing_font.render(f" You Lost!! ", 1, (255, 255, 255))
            game_Window.blit(lost_Title, (width / 2 - lost_Title.get_width() / 2, 150))

        pygame.display.update()

    while running:
        clock.tick(FPS)
        redraw()

        ''' Enemies spawning in randomly '''
        if len(enemies) == 0:
            level += 1  # +1 to players score
            wave_length += 3  # adding more enemies to spawn

            for i in range(wave_length):
                enemy = Enemy(random.randrange(50, width - 100), random.randrange(-1500, -100),
                              random.choice(["BLACK", "GREEN", "CYAN", "PURPLE", "YELLOW"]))
                enemies.append(enemy)

        # If players lives are less than 0, run lost screen
        if lives < 0:
            Lost = True
            lost_screen_timer += 1

        if Lost:
            if lost_screen_timer > FPS*5:   # Making the lost screen run for a set amount of FPS
                running = False
            else:
                continue

        """ CONTROLS FUNCTIONS """

        ''' QUIT '''
        for event in pygame.event.get():
            # QUIT function
            if event.type == pygame.QUIT:
                Quit_function()

        escape_button = pygame.key.get_pressed()
        if escape_button[pygame.K_ESCAPE]:
            running = False
            menu_page()

        """ Player Movement """
        keys = pygame.key.get_pressed()  # checks if keys are being pressed
        # Moving LEFT using either arrow or a
        if keys[pygame.K_LEFT] or keys[pygame.K_a] and player.x - player_velocity > 0:
            player.x -= player_velocity
        # RIGHT using arrow or d
        if keys[pygame.K_RIGHT] or keys[pygame.K_d] and player.x + player_velocity + player.get_width() < width:
            player.x += player_velocity

        """ Player Shooting """
        # Space bar to shoot laser
        if keys[pygame.K_SPACE]:
            player.shoot()
        # Mouse button to shoot
        if pygame.mouse.get_pressed()[0]:
            player.shoot()

        """ Enemy Spawning """
        # Creating enemies from the list made
        for enemy in enemies[:]:
            enemy.move(enemy_velocity)

            """ Collision between enemy and Player """
            if collide(enemy, player):
                lives -= 1
                enemies.remove(enemy)
                """ If enemy hits bottom of the screen, remove it """
            elif enemy.y + enemy.get_height() > height:
                lives -= 1
                enemies.remove(enemy)

        player.move_lasers(- laser_velocity, enemies)


""" Quit function to avoid the mouse event issue """
def Quit_function():
    pygame.quit()
    quit()


""" Menu Page """
def menu_page():
    menu_font = pygame.font.SysFont("comicsans", 50)
    menu_running = True
    while menu_running:
        menu_Window.blit(menu_BG, (0, 0))
        menu_label = menu_font.render("Press Space to begin... ", 1, (255, 255, 255))
        game_Window.blit(menu_label, (10, 360))
        pygame.display.update()

        keys = pygame.key.get_pressed()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # menu_running = False
                Quit_function()

            escape_button = pygame.key.get_pressed()
            if escape_button[pygame.K_ESCAPE]:
                Quit_function()
            if keys[pygame.K_SPACE]:
                main_Game()


menu_page()

